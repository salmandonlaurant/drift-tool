# Drift Tool — quick start (English)

A small local Windows app that turns SAP2000 storey-displacement tables into
stepped (staircase) storey-drift diagrams with a limit line, legend, and Excel /
SVG / PNG / PDF export. Nothing is uploaded; the app listens on `127.0.0.1`
only.

## Run

Double-click **`Drift Tool.bat`** (first run creates `.venv` and installs
`flask` + `openpyxl`; internet needed once). The browser opens automatically.
If it does not, use the address printed in the terminal
(`http://127.0.0.1:8765/`).

Manual start:

```powershell
python -m pip install -r requirements.txt
python server.py
```

## Use

1. **Curve data** tab → open **Paste data from SAP2000**.
2. Paste two or three columns: `storey`, `u`, optional `h` — separated by Tab,
   `;`, `|` or spaces. Decimal comma or dot both work.
3. Pick the **unit of u** (mm/cm/m) and **unit of h** (usually m).
4. Press **Parse & apply**.
5. Check the storey table: `Δu`, `d`, `d [%]`, and the status column
   (`✓`, `EXCEEDS`, `⚠`).
6. **Model / Heights** tab: fix heights if needed. `hᵢ` is the distance from
   level `i−1` to level `i`, **not** the elevation.
7. **Diagram** tab: set the limit (`0.002`, `0.2%` or `1/500` are equivalent)
   and tick the curves that belong to the diagram.
8. Export **Excel**, **SVG**, **PNG** or **PDF**, or **Save** the project as
   `.drift.json`.

## Calculation rules

```
Δuᵢ = uᵢ − uᵢ₋₁          (the base is subtracted only at storey 1)
dᵢ  = |Δuᵢ| / hᵢ         hᵢ = height between level i−1 and level i
exceeds: dᵢ > limit      (strict)
```

- A storey-0 row is required, or an explicitly confirmed base displacement.
- Missing / non-numeric values are flagged, never replaced with zero.
- Non-consecutive storeys are not bridged; duplicate storeys are reported.
- A bare `0.2` is **not** read as 0.2%. Write `0.2%` for a percentage.

## Language switch

Top-right button **EN / ΕΛ** switches the whole UI, chart labels and Excel
export. The choice is remembered in the browser.

## Warning: response spectrum

Combined peak displacements from a response-spectrum analysis may occur at
different instants, so subtracting them is not a valid drift. Export the
relative response from SAP or use an appropriate modal combination. The tool
shows a persistent warning when a curve is marked **Response spectrum**.

## Batch CLI

```powershell
python drift.py --project examples\demo.drift.json --out out\demo
python drift.py --in examples\wind-cbs.tsv --limit "0.2%" --name "Wind +X" --out out\wind
```

## More

- Full Greek guide (for non-technical users): [GUIDE_GR.md](GUIDE_GR.md)
- Technical README and tests: in the source repository.
